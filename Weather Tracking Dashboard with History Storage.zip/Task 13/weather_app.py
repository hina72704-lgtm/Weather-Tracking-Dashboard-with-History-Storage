import requests
import json
import os
from datetime import datetime
import matplotlib.pyplot as plt
from typing import Dict, List, Optional
import time

class WeatherDashboard:
    """Weather Tracking Dashboard with History Storage"""
    
    def __init__(self, api_key: str):
        """Initialize the weather dashboard with API key"""
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"  # Fixed: HTTPS
        self.history_file = "weather_history.json"
        self.load_history()
        self.create_sample_data()  # Add sample data if empty
    
    def create_sample_data(self):
        """Create sample weather data for testing"""
        if not self.history:
            print("\n📝 Creating sample data for testing...")
            sample_data = [
                {
                    "city": "New York",
                    "temperature": 22.5,
                    "humidity": 65,
                    "condition": "clear sky",
                    "wind_speed": 4.2,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "feels_like": 21.8,
                    "pressure": 1015
                },
                {
                    "city": "London",
                    "temperature": 15.3,
                    "humidity": 78,
                    "condition": "light rain",
                    "wind_speed": 5.1,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "feels_like": 14.5,
                    "pressure": 1012
                },
                {
                    "city": "Tokyo",
                    "temperature": 28.0,
                    "humidity": 55,
                    "condition": "few clouds",
                    "wind_speed": 3.8,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "feels_like": 27.2,
                    "pressure": 1018
                }
            ]
            self.history = sample_data
            self.save_history()
            print("✅ Sample data created! You can now test the analysis features.")
    
    def load_history(self):
        """Load weather history from JSON file"""
        if os.path.exists(self.history_file):
            with open(self.history_file, 'r') as file:
                self.history = json.load(file)
        else:
            self.history = []
    
    def save_history(self):
        """Save weather history to JSON file"""
        with open(self.history_file, 'w') as file:
            json.dump(self.history, file, indent=4)
    
    def fetch_weather(self, city: str) -> Optional[Dict]:
        """Fetch real-time weather data from OpenWeatherMap API"""
        response = None  # Initialize response variable to fix scope bug
        try:
            # Make API request
            params = {
                'q': city,
                'appid': self.api_key,
                'units': 'metric'  # Celsius units
            }
            
            response = requests.get(self.base_url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # Extract relevant weather information
            weather_data = {
                'city': data['name'],
                'temperature': data['main']['temp'],
                'humidity': data['main']['humidity'],
                'condition': data['weather'][0]['description'],
                'wind_speed': data['wind']['speed'],
                'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                'feels_like': data['main']['feels_like'],
                'pressure': data['main']['pressure']
            }
            
            return weather_data
            
        except requests.exceptions.RequestException as e:
            print(f"❌ Network error: Could not fetch weather data. Please check your internet connection.")
            print(f"   Details: {e}")
            return None
        except requests.exceptions.HTTPError as e:
            if response and response.status_code == 404:
                print(f"❌ City '{city}' not found. Please check the city name.")
            elif response and response.status_code == 401:
                print(f"❌ Invalid API key. Please check your OpenWeatherMap API key.")
                print(f"   Note: New API keys take 10-30 minutes to activate.")
            else:
                print(f"❌ API Error: {e}")
            return None
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            return None
    
    def validate_api_key(self) -> bool:
        """Test if API key works with a simple request"""
        test_city = "London"
        try:
            params = {
                'q': test_city,
                'appid': self.api_key,
                'units': 'metric'
            }
            response = requests.get(self.base_url, params=params, timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def display_weather(self, weather_data: Dict):
        """Display weather data in a clean format"""
        print("\n" + "="*50)
        print(f"🌍 WEATHER REPORT - {weather_data['city']}")
        print("="*50)
        print(f"🕒 Time: {weather_data['timestamp']}")
        print(f"🌡️ Temperature: {weather_data['temperature']}°C (Feels like: {weather_data['feels_like']}°C)")
        print(f"💧 Humidity: {weather_data['humidity']}%")
        print(f"🌤️ Condition: {weather_data['condition'].capitalize()}")
        print(f"💨 Wind Speed: {weather_data['wind_speed']} m/s")
        print(f"📊 Pressure: {weather_data['pressure']} hPa")
        print("="*50)
    
    def save_weather_data(self, weather_data: Dict):
        """Save weather data to history"""
        self.history.append(weather_data)
        self.save_history()
        print(f"✅ Weather data for {weather_data['city']} saved to history!")
    
    def view_history(self):
        """Display all historical weather records"""
        if not self.history:
            print("\n📭 No weather history available. Please fetch and save some weather data first.")
            return
        
        print("\n" + "="*80)
        print("📜 WEATHER HISTORY")
        print("="*80)
        
        for i, record in enumerate(self.history[-10:], 1):  # Show last 10 records
            print(f"\n{i}. {record['city']} - {record['timestamp']}")
            print(f"   🌡️ {record['temperature']}°C | 💧 {record['humidity']}% | 🌤️ {record['condition'].capitalize()}")
        
        print("\n" + "="*80)
        print(f"📊 Total records: {len(self.history)}")
    
    def analyze_trends(self, city: Optional[str] = None):
        """Analyze temperature trends and display graphs"""
        if not self.history:
            print("\n📭 No data available for analysis. Please save some weather records first.")
            return
        
        # Filter by city if specified
        if city:
            filtered_data = [record for record in self.history if record['city'].lower() == city.lower()]
            if not filtered_data:
                print(f"\n❌ No historical data found for city: {city}")
                return
            city_name = city.title()
        else:
            filtered_data = self.history
            city_name = "All Cities"
        
        # Prepare data for plotting
        temperatures = [record['temperature'] for record in filtered_data]
        humidities = [record['humidity'] for record in filtered_data]
        timestamps = [record['timestamp'][5:10] for record in filtered_data]  # MM-DD format
        
        if len(temperatures) < 2:
            print("\n⚠️ Need at least 2 records for trend analysis.")
            return
        
        # Calculate statistics
        avg_temp = sum(temperatures) / len(temperatures)
        max_temp = max(temperatures)
        min_temp = min(temperatures)
        avg_humidity = sum(humidities) / len(humidities)
        
        # Display analysis
        print("\n" + "="*60)
        print(f"📊 WEATHER TRENDS ANALYSIS - {city_name}")
        print("="*60)
        print(f"📈 Temperature Statistics:")
        print(f"   • Average: {avg_temp:.1f}°C")
        print(f"   • Maximum: {max_temp:.1f}°C")
        print(f"   • Minimum: {min_temp:.1f}°C")
        print(f"   • Range: {max_temp - min_temp:.1f}°C")
        print(f"\n💧 Average Humidity: {avg_humidity:.1f}%")
        print(f"📝 Number of records: {len(temperatures)}")
        
        # Create temperature trend graph
        plt.figure(figsize=(10, 6))
        
        plt.subplot(2, 1, 1)
        plt.plot(timestamps, temperatures, 'r-o', linewidth=2, markersize=6)
        plt.title(f'Temperature Trends - {city_name}', fontsize=14, fontweight='bold')
        plt.xlabel('Date (MM-DD)')
        plt.ylabel('Temperature (°C)')
        plt.grid(True, alpha=0.3)
        plt.xticks(rotation=45)
        
        plt.subplot(2, 1, 2)
        plt.plot(timestamps, humidities, 'b-o', linewidth=2, markersize=6)
        plt.title(f'Humidity Trends - {city_name}', fontsize=14, fontweight='bold')
        plt.xlabel('Date (MM-DD)')
        plt.ylabel('Humidity (%)')
        plt.grid(True, alpha=0.3)
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        plt.show()
    
    def filter_by_date(self, date: str):
        """Filter history records by date"""
        filtered = [record for record in self.history if record['timestamp'].startswith(date)]
        
        if not filtered:
            print(f"\n❌ No records found for date: {date}")
            return
        
        print(f"\n📅 Records for {date}:")
        for record in filtered:
            print(f"   • {record['city']}: {record['temperature']}°C, {record['condition'].capitalize()}")
    
    def get_weather_alert(self, weather_data: Dict):
        """Check for weather alerts and display warnings"""
        alerts = []
        
        # Check for rain
        if 'rain' in weather_data['condition'].lower():
            alerts.append("🌧️ RAIN ALERT: Rain detected! Consider carrying an umbrella.")
        
        # Check for storm
        if 'storm' in weather_data['condition'].lower() or 'thunder' in weather_data['condition'].lower():
            alerts.append("⚡ STORM WARNING: Severe weather conditions! Stay safe indoors.")
        
        # Check for extreme temperature
        if weather_data['temperature'] > 35:
            alerts.append("🔥 HEAT WARNING: Extreme heat! Stay hydrated and avoid direct sunlight.")
        elif weather_data['temperature'] < 0:
            alerts.append("❄️ FREEZE WARNING: Below freezing temperatures! Dress warmly.")
        
        # Check for high wind
        if weather_data['wind_speed'] > 15:
            alerts.append("💨 HIGH WIND WARNING: Strong winds detected! Secure outdoor items.")
        
        # Check for low visibility (fog)
        if 'fog' in weather_data['condition'].lower():
            alerts.append("🌫️ FOG ALERT: Low visibility! Drive carefully.")
        
        if alerts:
            print("\n" + "🚨" * 15)
            print("⚠️ WEATHER ALERTS ⚠️")
            print("🚨" * 15)
            for alert in alerts:
                print(f"• {alert}")
            print("🚨" * 15 + "\n")
    
    def run(self):
        """Main menu system"""
        while True:
            print("\n" + "🌟" * 20)
            print("🌤️ WEATHER TRACKING DASHBOARD")
            print("🌟" * 20)
            print("1️⃣  Get Current Weather")
            print("2️⃣  View History")
            print("3️⃣  Analyze Data")
            print("4️⃣  Filter by Date")
            print("5️⃣  Save Current Data")
            print("6️⃣  Exit")
            print("🌟" * 20)
            
            choice = input("\n👉 Enter your choice (1-6): ").strip()
            
            if choice == '1':
                city = input("🏙️ Enter city name: ").strip()
                if city:
                    weather = self.fetch_weather(city)
                    if weather:
                        self.display_weather(weather)
                        self.get_weather_alert(weather)
                        save_now = input("\n💾 Save this weather data to history? (y/n): ").lower()
                        if save_now == 'y':
                            self.save_weather_data(weather)
            
            elif choice == '2':
                self.view_history()
            
            elif choice == '3':
                city_filter = input("📊 Analyze for specific city? (leave empty for all): ").strip()
                self.analyze_trends(city_filter if city_filter else None)
            
            elif choice == '4':
                date = input("📅 Enter date (YYYY-MM-DD): ").strip()
                self.filter_by_date(date)
            
            elif choice == '5':
                if self.history:
                    # Save current history to a backup file
                    backup_file = f"weather_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                    with open(backup_file, 'w') as f:
                        json.dump(self.history, f, indent=4)
                    print(f"✅ Data saved to {backup_file}")
                else:
                    print("❌ No data to save!")
            
            elif choice == '6':
                print("\n👋 Thank you for using Weather Dashboard! Goodbye! 🌟")
                break
            
            else:
                print("❌ Invalid choice! Please enter a number between 1-6.")

def main():
    """Main function to run the application"""
    print("🌦️ WEATHER TRACKING DASHBOARD SETUP")
    print("-" * 35)
    print("To use this application, you need an OpenWeatherMap API key.")
    print("Get your free API key at: https://openweathermap.org/api")
    print("-" * 35)
    
    # Get API key
    api_key = input("\n🔑 Enter your OpenWeatherMap API key: ").strip()
    
    if not api_key:
        print("❌ API key is required to use this application!")
        return
    
    # Create dashboard
    dashboard = WeatherDashboard(api_key)
    
    # Validate API key (optional)
    print("\n🔍 Validating API key...")
    if dashboard.validate_api_key():
        print("✅ API key is valid! Ready to fetch weather data.")
    else:
        print("⚠️ API key validation failed. It may still be activating.")
        print("   New API keys take 10-30 minutes to activate.")
        print("   You can still use the dashboard with sample data.")
        proceed = input("   Continue anyway? (y/n): ").lower()
        if proceed != 'y':
            return
    
    # Run the dashboard
    dashboard.run()

if __name__ == "__main__":
    main()